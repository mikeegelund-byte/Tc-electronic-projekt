using FluentAssertions;
using Nova.Infrastructure.Midi;
using Nova.Midi;
using Xunit;

namespace Nova.Infrastructure.Tests.Midi;

public class DryWetMidiPortTests
{
    [Fact]
    public void DryWetMidiPort_Implements_IMidiPort()
    {
        var port = new DryWetMidiPort();
        port.Should().BeAssignableTo<IMidiPort>();
    }

    [Fact]
    public void Name_BeforeConnect_ReturnsEmpty()
    {
        var port = new DryWetMidiPort();
        port.Name.Should().BeEmpty();
    }

    [Fact]
    public void IsConnected_BeforeConnect_ReturnsFalse()
    {
        var port = new DryWetMidiPort();
        port.IsConnected.Should().BeFalse();
    }

    [Fact]
    public void GetAvailablePorts_ReturnsListOfPortNames()
    {
        // This test may return empty list if no MIDI devices connected
        var port = new DryWetMidiPort();
        var inputs = port.GetAvailableInputPorts();
        var outputs = port.GetAvailableOutputPorts();
        inputs.Should().NotBeNull();
        outputs.Should().NotBeNull();
        inputs.Should().BeOfType<List<string>>();
        outputs.Should().BeOfType<List<string>>();
    }

    [Fact]
    public async Task ConnectAsync_WithInvalidPort_ReturnsFailure()
    {
        var port = new DryWetMidiPort();
        var result = await port.ConnectAsync(new MidiPortSelection("NonExistent In 12345", "NonExistent Out 12345"));
        result.IsFailed.Should().BeTrue();
        result.Errors.Should().ContainSingle();
        result.Errors[0].Message.Should().Contain("not found");
    }

    [Fact]
    public async Task ConnectAsync_SetsNameProperty()
    {
        // This would need a mock device - but we can at least test the error path
        var port = new DryWetMidiPort();
        var result = await port.ConnectAsync(new MidiPortSelection("Test In", "Test Out"));
        // Should fail since port doesn't exist
        result.IsFailed.Should().BeTrue();
        port.Name.Should().BeEmpty(); // Name only set on success
    }

    [Fact]
    public async Task DisconnectAsync_BeforeConnect_ReturnsSuccess()
    {
        var port = new DryWetMidiPort();
        var result = await port.DisconnectAsync();
        result.IsSuccess.Should().BeTrue();
    }

    [Fact]
    public async Task DisconnectAsync_ClearsName()
    {
        var port = new DryWetMidiPort();
        // Simulate connection by manually setting name (since ConnectAsync not yet impl)
        // After disconnect, name should be empty
        var result = await port.DisconnectAsync();
        result.IsSuccess.Should().BeTrue();
        port.Name.Should().BeEmpty();
    }

    [Fact]
    public async Task SendSysExAsync_NotConnected_ReturnsFail()
    {
        var port = new DryWetMidiPort();
        var sysex = new byte[] { 0xF0, 0x41, 0x10, 0x42, 0x12, 0x7F, 0x7F, 0xF7 };
        var result = await port.SendSysExAsync(sysex);
        result.IsFailed.Should().BeTrue();
    }

    [Fact]
    public void SendSysExAsync_WithValidData_SkippedForManualTesting()
    {
        // This test requires actual MIDI device - skip in CI
        // Marked for manual testing only
    }

    [Fact]
    public async Task ReceiveSysExAsync_NotConnected_ThrowsInvalidOperationException()
    {
        var port = new DryWetMidiPort();
        var cts = new CancellationTokenSource();
        
        var act = async () =>
        {
            await foreach (var msg in port.ReceiveSysExAsync(cts.Token))
            {
                // Should not reach here
            }
        };
        
        await act.Should().ThrowAsync<InvalidOperationException>()
            .WithMessage("*Not connected*");
    }

    [Fact]
    public async Task ReceiveSysExAsync_WithCancellation_StopsEnumeration()
    {
        // This test would require a mock device setup
        // Testing cancellation behavior in isolation
        var port = new DryWetMidiPort();
        var cts = new CancellationTokenSource();
        cts.Cancel(); // Cancel immediately
        
        var count = 0;
        try
        {
            await foreach (var msg in port.ReceiveSysExAsync(cts.Token))
            {
                count++;
            }
        }
        catch (OperationCanceledException)
        {
            // Expected
        }
        catch (InvalidOperationException)
        {
            // Also acceptable - not connected
        }
        
        count.Should().Be(0); // Should not receive any messages
    }
}
