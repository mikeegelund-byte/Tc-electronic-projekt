namespace Nova.Presentation.Views;

public partial class SystemSettingsView : Avalonia.Controls.UserControl
{
    public SystemSettingsView()
    {
        InitializeComponent();
    }
}
