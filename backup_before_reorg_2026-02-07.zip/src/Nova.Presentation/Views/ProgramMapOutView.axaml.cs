using Avalonia.Controls;

namespace Nova.Presentation.Views;

public partial class ProgramMapOutView : UserControl
{
    public ProgramMapOutView()
    {
        InitializeComponent();
    }
}
