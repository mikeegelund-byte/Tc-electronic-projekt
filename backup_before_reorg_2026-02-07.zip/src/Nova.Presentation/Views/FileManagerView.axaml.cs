using Avalonia.Controls;

namespace Nova.Presentation.Views;

public partial class FileManagerView : UserControl
{
    public FileManagerView()
    {
        InitializeComponent();
    }
}
