using Avalonia.Controls;

namespace Nova.Presentation.Views;

public partial class ProgramMapInView : UserControl
{
    public ProgramMapInView()
    {
        InitializeComponent();
    }
}
