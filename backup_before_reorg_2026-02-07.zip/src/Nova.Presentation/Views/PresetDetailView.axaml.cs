using Avalonia.Controls;

namespace Nova.Presentation.Views;

public partial class PresetDetailView : UserControl
{
    public PresetDetailView()
    {
        InitializeComponent();
    }
}
