using Avalonia.Controls;

namespace Nova.Presentation.Views;

public partial class PedalMappingView : UserControl
{
    public PedalMappingView()
    {
        InitializeComponent();
    }
}
