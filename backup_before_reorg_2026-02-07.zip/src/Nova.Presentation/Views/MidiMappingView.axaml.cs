using Avalonia.Controls;

namespace Nova.Presentation.Views;

/// <summary>
/// View for MIDI CC Mapping Editor (Module 9 - Task 9.1.1).
/// </summary>
public partial class MidiMappingView : UserControl
{
    public MidiMappingView()
    {
        InitializeComponent();
    }
}
