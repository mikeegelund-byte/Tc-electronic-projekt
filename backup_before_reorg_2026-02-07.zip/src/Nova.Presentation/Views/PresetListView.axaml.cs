using Avalonia.Controls;

namespace Nova.Presentation.Views;

public partial class PresetListView : UserControl
{
    public PresetListView()
    {
        InitializeComponent();
    }
}
