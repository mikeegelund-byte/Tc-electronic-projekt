using Avalonia.Controls;

namespace Nova.Presentation;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}